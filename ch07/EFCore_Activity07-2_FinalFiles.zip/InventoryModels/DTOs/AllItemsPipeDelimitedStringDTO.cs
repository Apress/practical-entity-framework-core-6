﻿namespace InventoryModels.DTOs
{
    public class AllItemsPipeDelimitedStringDto
    {
        public string AllItems { get; set; } = string.Empty;
    }
}
