﻿namespace InventoryModels.DTOs
{
    public class CategoryDto
    {
        public int Id { get; set; }
    }
}
