﻿using InventoryModels.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace InventoryBusinessLayer
{
    public interface ICategoriesService
    {
        Task<List<CategoryDto>> ListCategoriesAndDetails();
    }
}
