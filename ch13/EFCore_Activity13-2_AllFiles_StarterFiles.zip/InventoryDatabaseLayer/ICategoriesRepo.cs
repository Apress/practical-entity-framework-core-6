﻿using InventoryModels.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace InventoryDatabaseLayer
{
    public interface ICategoriesRepo
    {
        Task<List<CategoryDto>> ListCategoriesAndDetails();
    }
}
