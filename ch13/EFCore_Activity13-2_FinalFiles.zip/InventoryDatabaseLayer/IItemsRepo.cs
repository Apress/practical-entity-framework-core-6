﻿using InventoryModels;
using InventoryModels.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace InventoryDatabaseLayer
{
    public interface IItemsRepo
    {
        Task<List<Item>> GetItems();
        Task<List<ItemDto>> GetItemsByDateRange(DateTime minDateValue, DateTime maxDateValue);
        Task<List<GetItemsForListingDto>> GetItemsForListingFromProcedure();
        Task<List<GetItemsTotalValueDto>> GetItemsTotalValues(bool isActive);
        Task<List<FullItemDetailDto>> GetItemsWithGenresAndCategories();

        Task<int> UpsertItem(Item item);
        Task UpsertItems(List<Item> items);
        Task DeleteItem(int id);
        Task DeleteItems(List<int> itemIds);
    }

}
