﻿namespace InventoryModels.DTOs
{
    public class CategoryDetailDto
    {
        public string Color { get; set; }
        public string Value { get; set; }
    }

}
