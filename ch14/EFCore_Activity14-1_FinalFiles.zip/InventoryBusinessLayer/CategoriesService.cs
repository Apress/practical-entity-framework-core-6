﻿using AutoMapper;
using EFCore_DBLibrary;
using InventoryDatabaseLayer;
using InventoryModels.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace InventoryBusinessLayer
{
    public class CategoriesService : ICategoriesService
    {
        private readonly ICategoriesRepo _dbRepo;

        public CategoriesService(InventoryDbContext dbContext, IMapper mapper)
        {
            _dbRepo = new CategoriesRepo(dbContext, mapper);
        }

        public async Task<List<CategoryDto>> ListCategoriesAndDetails()
        {
            return await _dbRepo.ListCategoriesAndDetails();
        }
    }
}
