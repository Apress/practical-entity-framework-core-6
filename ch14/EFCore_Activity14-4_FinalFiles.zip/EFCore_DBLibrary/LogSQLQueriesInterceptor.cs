﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Data.Common;

namespace EFCore_DBLibrary
{
    public class LogSQLQueriesInterceptor : DbCommandInterceptor
    {
        private int _longRunningQueryThreshold = 10;
        private string _logQueriesFilePath = $@"C:\Data\{Environment.MachineName}_longQueries.txt";

        public override ValueTask<DbDataReader> ReaderExecutedAsync(DbCommand command, CommandExecutedEventData eventData
                , DbDataReader result, CancellationToken cancellationToken = default(CancellationToken))
        {
            if (eventData.Duration.TotalMilliseconds >= _longRunningQueryThreshold)
            {
                File.AppendAllText(_logQueriesFilePath
                    , $"{command.CommandText} MS: {eventData.Duration.TotalMilliseconds}" +
                        $"{Environment.NewLine}{Environment.NewLine}");
            }

            return base.ReaderExecutedAsync(command, eventData, result, cancellationToken);
        }
    }
}
