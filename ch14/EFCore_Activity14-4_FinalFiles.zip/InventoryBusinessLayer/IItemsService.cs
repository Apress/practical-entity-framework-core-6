﻿using InventoryModels.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace InventoryBusinessLayer
{
    public interface IItemsService
    {
        Task<List<ItemDto>> GetItems();
        Task<List<ItemDto>> GetItemsByDateRange(DateTime minDateValue, DateTime maxDateValue);
        Task<List<GetItemsForListingDto>> GetItemsForListingFromProcedure();
        Task<List<GetItemsTotalValueDto>> GetItemsTotalValues(bool isActive);
        Task<string> GetAllItemsPipeDelimitedString();
        Task<List<FullItemDetailDto>> GetItemsWithGenresAndCategories();

        Task<int> UpsertItem(CreateOrUpdateItemDto item);
        Task UpsertItems(List<CreateOrUpdateItemDto> item);
        Task DeleteItem(int id);
        Task DeleteItems(List<int> itemIds);
    }
}
