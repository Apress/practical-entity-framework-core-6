﻿using EFCore_DBLibrary;
using InventoryHelpers;
using InventoryModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EFCore_Activity1502
{
    public class Program
    {
        private static IConfigurationRoot _configuration;
        private static DbContextOptionsBuilder<InventoryDbContext> _optionsBuilder;
        private const string _loggedInUserId = "e2eb8989-a81a-4151-8e86-eb95a7961da2";

        static void Main(string[] args)
        {
            BuildOptions();
            DeleteAllItems();
            DeleteAllCategories();
            EnsureCategories();
            EnsureItems();
            UpdateItems();
            //ListInventory();
            //FindItemsByCategory();
            //FindItemsByAdditionalProperty();
            //StringConcatWithMultipleArguments();
            //EFFunctionsRandom();
            IsNullOrWhiteSpaceReview();

            Console.WriteLine("Program completed");
        }

        static void BuildOptions()
        {
            _configuration = ConfigurationBuilderSingleton.ConfigurationRoot;
            _optionsBuilder = new DbContextOptionsBuilder<InventoryDbContext>();
            _optionsBuilder.UseSqlServer(_configuration.GetConnectionString("InventoryManager"));
        }

        private static void DeleteAllCategories()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var categories = db.Categories.ToList();
                db.Categories.RemoveRange(categories);
                db.SaveChanges();
            }
        }

        private static void EnsureCategories()
        {
            EnsureCategory("Digital", "Blue", "#0000FF");
            EnsureCategory("Physical", "Green", "#00FF00");
            EnsureCategory("Pre-Release", "Red", "#FF0000");
        }

        private static void EnsureCategory(string name, string color, string colorValue)
        {
            
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                //determine if item exists:
                var existingItem = db.Categories.FirstOrDefault(x => x.Name.ToLower()
                                                            == name.ToLower());

                if (existingItem == null)
                {
                    //doesn't exist, add it.
                    var category = new Category
                    {
                        Color = color,
                        ColorValue = colorValue,
                        Name = name,
                        IsActive = true,
                        CreatedByUserId = _loggedInUserId
                    };

                    db.Categories.Add(category);
                    db.SaveChanges();
                }
            }
        }

        static void EnsureItems()
        {
            var categories = new List<Category>();

            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                categories = db.Categories.ToList();
            }

            EnsureItem("Batman Begins", "You either die the hero or live long enough to see yourself become the villain", "Christian Bale, Katie Holmes", categories);
            EnsureItem("Inception", "You mustn't be afraid to dream a little bigger, darling", "Leonardo DiCaprio, Tom Hardy, Joseph Gordon-Levitt", categories);
            EnsureItem("Remember the Titans", "Left Side, Strong Side", "Denzell Washington, Will Patton", categories);
            EnsureItem("Star Wars: The Empire Strikes Back", "He will join us or die, master", "Harrison Ford, Carrie Fisher, Mark Hamill", categories);
            EnsureItem("Top Gun", "I feel the need, the need for speed!", "Tom Cruise, Anthony Edwards, Val Kilmer", categories);
            EnsureItem("The Prestige", "Now you're looking for the secret. But you won't find it because of course, you're not really looking. You don't really want to work it out. You want to be fooled.", "Michael Caine, Christian Bale, Hugh Jackman", categories);
            EnsureItem("WarGames", "Intersting game. The only way to win is not to play.", "Matthew Broderick", categories);
            EnsureItem("Stand By Me", "I never had any friends later on like the ones I had when I was 12", "Wil Wheaton, Jerry O'Connell, Corey Feldman, River Phoenix", categories);
            EnsureItem("Liar Liar", "The pen is blue. The pen is blue. The #$#^*!(# pen is blue", "Jim Carrey", categories);
            EnsureItem("Apollo 13", "Houston, we have a problem", "Tom Hanks, Gary Sinise, Kevin Bacon, Ed Harris", categories);
            EnsureItem("Hitch", "Never lie, steal, cheat, or drink. But if you must lie, lie in the arms of the one you love. If you must steal, steal away from bad company. If you must cheat, cheat death", "Wil Smith, Eva Mendes, Kevin James", categories);
            EnsureItem("The Martian", "So Mars is international waters. Now, NASA is an American non-military organization, it owns the Hab. But the second I walk outside I'm in international waters. So Here's the cool part. I'm about to leave for the Schiaparelli Crater where I'm going to commandeer the Ares IV lander. Nobody explicitly gave me permission to do this, and they can't until I'm on board the Ares IV. So I'm going to be taking a craft over in international waters without permission, which by definition... makes me a pirate. Mark Watney: Space Pirate.", "Matt Damon", categories);
        }

        private static void EnsureItem(string name, string description, string notes, List<Category> categories)
        {
            Random r = new Random();
            var maxCatId = categories.Count();
            var useCategory = r.Next(0, maxCatId);
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                //determine if item exists:
                var existingItem = db.Items.FirstOrDefault(x => x.Name.ToLower()
                                                            == name.ToLower());

                if (existingItem == null)
                {

                    //doesn't exist, add it.
                    var item = new Item()
                    {
                        Name = name,
                        CreatedByUserId = _loggedInUserId,
                        IsActive = true,
                        Quantity = r.Next(),
                        Description = description,
                        Notes = notes,
                        CategoryId = categories[useCategory].Id,
                        AdditionalProperties = GenerateAdditionalProperties(r.Next(0, 99)),
                        PurchasePrice = r.Next(4, 33)
                    };
                    db.Items.Add(item);
                    db.SaveChanges();
                }
            }
        }

        private static List<AdditionalProperty> GenerateAdditionalProperties(int modifier)
        {
            if (modifier % 2 == 0)
            {
                return new List<AdditionalProperty>() {
                    new AdditionalProperty() { Name = "Genre", Value="Sci/Fi"},
                    new AdditionalProperty() { Name = "Rating", Value="PG"},
                    new AdditionalProperty() { Name = "RottenTomatoes", Value="68/45"},
                };
            }
            else
            {
                return new List<AdditionalProperty>() {
                    new AdditionalProperty() { Name = "Genre", Value="Action"},
                    new AdditionalProperty() { Name = "Rating", Value="R"},
                    new AdditionalProperty() { Name = "RottenTomatoes", Value="92/71"},
                };
            }
        }

        private static void ListInventory()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var items = db.Items
                                .AsNoTracking()
                                .Select(x => new
                                {
                                    ItemName = x.Name,
                                    CategoryName = x.Category.Name,
                                    CategoryColor = x.Category.Color
                                }).OrderBy(x => x.ItemName).ToList();
                items.ForEach(x => Console.WriteLine($"New Item: {x.ItemName} has Category {x.CategoryName} with color {x.CategoryColor}"));
            }
        }

        private static void DeleteAllItems()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var items = db.Items.ToList();
                db.Items.RemoveRange(items);
                db.SaveChanges();
            }
        }

        private static void UpdateItems()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var items = db.Items.ToList();
                foreach (var item in items)
                {
                    item.CurrentOrFinalPrice = 9.99M;
                }
                db.Items.UpdateRange(items);
                db.SaveChanges();
            }
        }

        private static void FindItemsByCategory()
        {
            Console.WriteLine("Please enter the filter to use for searching items by category (i.e. 'Blue' or 'Digital'):");
            var filter = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(filter))
            {
                Console.WriteLine("No filter was supplied. Exiting.");
                return;
            }

            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var filteredItems = db.Items
                                .AsNoTracking()
                                .Select(x => new
                                {
                                    ItemName = x.Name,
                                    Category = x.Category,
                                    CategoryName = x.Category.Name,
                                    CategoryColor = x.Category.Color,
                                    CategoryColorValue = x.Category.ColorValue
                                })
                                .Where(x => x.CategoryName.Contains(filter)
                                        || x.CategoryColor.Contains(filter)
                                        || x.CategoryColorValue.Contains(filter))
                                .OrderBy(x => x.ItemName).ToList();

                filteredItems.ForEach(x => Console.WriteLine($"New Item: {x.ItemName} " +
                                        $"has Category {x.CategoryName} " +
                                        $"with color {x.CategoryColor}"));
            }
        }

        private static void FindItemsByAdditionalProperty()
        {
            Console.WriteLine("Please enter the filter to use for searching items by additional properties:");
            var filter = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(filter))
            {
                Console.WriteLine("No filter was supplied. Exiting.");
                return;
            }

            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var filteredItems = db.Items
                                .AsNoTracking()
                                .Select(x => new
                                {
                                    ItemName = x.Name,
                                    AdditionalProperties = x.AdditionalProperties
                                })
                                .Where(i => EF.Functions.Contains(i.AdditionalProperties, filter))
                                .OrderBy(x => x.ItemName).ToList();

                foreach (var item in filteredItems)
                {
                    Console.WriteLine($"New Item: {item.ItemName}");
                    item.AdditionalProperties.ForEach(ap => Console.WriteLine($"AP: {ap.Name} | {ap.Value}"));
                }
            }
        }

        private static void StringConcatWithMultipleArguments()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                //in the past, you could only concat two
                var result = db.Items
                                .AsNoTracking()
                                .Select(x => new
                                {
                                    ItemName = x.Name,
                                    ItemDetail = string.Concat("Item: ", x.Name
                                                    , " Description: ", x.Description 
                                                    , " Notes: ", x.Notes),
                                    Category = x.Category,
                                    CategoryDetail = string.Concat("Category: ", x.Category.Name
                                                        , " Color: ", x.Category.Color
                                                        , " Value: ", x.Category.ColorValue)
                                })
                                .OrderBy(x => x.ItemName).ToList();

                result.ForEach(x => Console.WriteLine($"{x.ItemDetail} | {x.CategoryDetail}"));
            }
        }

        private static void EFFunctionsRandom()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var items = db.Items.AsNoTracking()
                                .Where(i => i.PurchasePrice >= (decimal)(EF.Functions.Random() * 33) + 1)
                                .ToList();
                items.ForEach(x => Console.WriteLine($"{x.Name} | {x.PurchasePrice}"));
            }
        }

        private static void IsNullOrWhiteSpaceReview()
        {
            using (var db = new InventoryDbContext(_optionsBuilder.Options))
            {
                var items = db.Items.AsNoTracking()
                                .Where(i => string.IsNullOrWhiteSpace(i.Description)
                                                || string.IsNullOrWhiteSpace(i.Notes))
                                .ToList();
                items.ForEach(x => Console.WriteLine($"{x.Name} | has null or whitespace in description or notes"));
            }
        }
    }
}
