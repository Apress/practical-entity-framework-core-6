﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFCore_DBLibrary.Migrations
{
    public partial class initialmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //intentionally blank, generated as a restore point for learning activities
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //intentionally blank, generated as a restore point for learning activities.
        }
    }
}
