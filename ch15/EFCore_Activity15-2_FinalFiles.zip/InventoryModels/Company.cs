﻿using System.ComponentModel.DataAnnotations;

namespace InventoryModels
{
    public class Company : Player
    {
        [StringLength(150)]
        public string CompanyName { get; set; }

        [StringLength(10)]
        public string StockSymbol { get; set; }

        [StringLength(50)]
        public string City { get; set; }

        public override string Name => $"{CompanyName} - {StockSymbol}";
    }

}
