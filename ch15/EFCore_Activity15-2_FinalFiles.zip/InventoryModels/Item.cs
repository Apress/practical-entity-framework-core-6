﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace InventoryModels
{
    [EntityTypeConfiguration(typeof(ItemConfiguration))]
    public class Item : FullAuditModel
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
        public string Description { get; set; }
        public string Notes { get; set; }
        public bool IsOnSale { get; set; }
        public DateTime? PurchasedDate { get; set; }
        public DateTime? SoldDate { get; set; }
        [Precision(18, 2)]
        public decimal? PurchasePrice { get; set; }
        public decimal? CurrentOrFinalPrice { get; set; }

        [StringLength(50)]
        public string nonUnicodeValueFluentAPI { get; set; }
        [StringLength(50)]
        [Unicode(false)]
        public string nonUnicodeValueAttribute { get; set; }
        [StringLength(50)]
        public string UnicodeValueFluentAPI { get; set; }
        [StringLength(50)]
        [Unicode(true)]
        public string UnicodeValueAttribute { get; set; }

        public virtual int CategoryId { get; set; }
        public virtual Category Category { get; set; }

        public List<AdditionalProperty> AdditionalProperties { get; set; }

        public virtual List<Player> Players { get; set; }
    }

}
