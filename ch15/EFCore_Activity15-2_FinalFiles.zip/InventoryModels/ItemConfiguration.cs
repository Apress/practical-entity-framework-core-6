﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace InventoryModels
{
    public class ItemConfiguration : IEntityTypeConfiguration<Item>
    {
        public void Configure(EntityTypeBuilder<Item> builder)
        {
            var options = new JsonSerializerOptions() { WriteIndented = false };
            builder
                .Property(x => x.CurrentOrFinalPrice)
                .HasPrecision(18, 2);
            builder
                .Property(x => x.nonUnicodeValueFluentAPI)
                .IsUnicode(false);
            builder
                .Property(x => x.UnicodeValueFluentAPI)
                .IsUnicode(true);
            builder
                .HasOne(i => i.Category)
                .WithMany(ci => ci.CategoryItems)
                .HasForeignKey(i => i.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
            builder
                .Property(i => i.AdditionalProperties)
                .HasConversion(ap => JsonSerializer.Serialize(ap, options),
                                ap => JsonSerializer.Deserialize<List<AdditionalProperty>>(ap, options),
                                new ValueComparer<List<AdditionalProperty>>(
                                    (c1, c2) => c1.SequenceEqual(c2),
                                    c => c.Aggregate(0, (a, v) => HashCode.Combine(a, v.GetHashCode())),
                                    c => c.ToList()));

        }

    }

}
