﻿using System.ComponentModel.DataAnnotations;

namespace InventoryModels
{
    public class Person : Player
    {
        [StringLength(50)]
        public string FirstName { get; set; }
        [StringLength(250)]
        public string LastName { get; set; }

        public override string Name => $"{FirstName} {LastName}";
    }

}
