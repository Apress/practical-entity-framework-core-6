﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryModels
{
    [EntityTypeConfiguration(typeof(CategoryConfiguration))]
    public class Category : FullAuditModel
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public string ColorValue { get; set; }

        public virtual List<Item> CategoryItems { get; set; }
    }
}
