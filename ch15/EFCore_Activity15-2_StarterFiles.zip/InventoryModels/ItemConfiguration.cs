﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InventoryModels
{
    public class ItemConfiguration : IEntityTypeConfiguration<Item>
    {
        public void Configure(EntityTypeBuilder<Item> builder)
        {
            builder
                .Property(x => x.CurrentOrFinalPrice)
                .HasPrecision(18, 2);
            builder
                .Property(x => x.nonUnicodeValueFluentAPI)
                .IsUnicode(false);
            builder
                .Property(x => x.UnicodeValueFluentAPI)
                .IsUnicode(true);
            builder
                .HasOne(i => i.Category)
                .WithMany(ci => ci.CategoryItems)
                .HasForeignKey(i => i.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
        }

    }

}
