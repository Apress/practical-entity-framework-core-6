﻿namespace InventoryModels.Interfaces
{
    public interface IActivatableModel
    {
        public bool IsActive { get; set; }
    }
}
