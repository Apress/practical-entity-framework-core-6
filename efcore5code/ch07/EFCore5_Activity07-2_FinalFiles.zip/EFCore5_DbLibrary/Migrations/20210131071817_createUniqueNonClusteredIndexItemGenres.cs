﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFCore5_DbLibrary.Migrations
{
    public partial class createUniqueNonClusteredIndexItemGenres : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ItemGenre_ItemId",
                table: "ItemGenre");

            migrationBuilder.CreateIndex(
                name: "IX_ItemGenre_ItemId_GenreId",
                table: "ItemGenre",
                columns: new[] { "ItemId", "GenreId" },
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_ItemGenre_ItemId_GenreId",
                table: "ItemGenre");

            migrationBuilder.CreateIndex(
                name: "IX_ItemGenre_ItemId",
                table: "ItemGenre",
                column: "ItemId");
        }
    }
}
