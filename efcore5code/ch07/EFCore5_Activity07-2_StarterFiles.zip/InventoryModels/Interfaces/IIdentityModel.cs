﻿namespace InventoryModels.Interfaces
{
    public interface IIdentityModel
    {
        public int Id { get; set; }
    }
}
