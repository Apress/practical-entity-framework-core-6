﻿using EFCore5_DbLibrary;
using InventoryModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryDataMigrator
{
    public class BuildPlayers
    {
        private readonly InventoryDbContext _context;
        private const string SEED_USER_ID = "31412031-7859-429c-ab21-c2e3e8d98042";

        public BuildPlayers(InventoryDbContext context)
        {
            _context = context;
        }

        public void ExecuteSeed()
        {
            if (_context.Categories.Count() == 0)
            {
                _context.Players.AddRange(
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000288/",Name = "Christian Bale"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0005017/",Name = "Katie Holmes"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000138/",Name = "Leonardo DiCaprio"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0362766/",Name = "Tom Hardy"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0330687/",Name = "Joseph Gordon-Levitt"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000243/",Name = "Denzel Washington"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0001599/",Name = "Will Patton"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000148/",Name = "Harrison Ford"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000402/",Name = "Carrie Fisher"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000434/",Name = "Mark Hamill"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000129/",Name = "Tom Cruise"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000381",Name = "Anthony Edwards"},
                    new Player() { CreatedDate = DateTime.Now,IsActive = true,IsDeleted = false,CreatedByUserId = SEED_USER_ID,
                        Description = "https://www.imdb.com/name/nm0000174/",Name = "Val Kilmer"
                    }
                );
                _context.SaveChanges();
            }

        }
    }
}
