﻿using EFCore5_DbLibrary;
using InventoryModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryDataMigrator
{
    public class BuildCategories
    {
        private readonly InventoryDbContext _context;

        public BuildCategories(InventoryDbContext context)
        {
            _context = context;
        }

        public void ExecuteSeed()
        {
            if (_context.Categories.Count() == 0)
            {
                _context.Categories.AddRange(
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Movies",
                        CategoryDetail = new CategoryDetail() { ColorValue = "#0000FF", ColorName = "Blue" }
                    },
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Books",
                        CategoryDetail = new CategoryDetail() { ColorValue = "#FF0000", ColorName = "Red" }
                    },
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Games",
                        CategoryDetail = new CategoryDetail() { ColorValue = "#008000", ColorName = "Green" }
                    }
                );
                _context.SaveChanges();
            }

        }
    }

}
