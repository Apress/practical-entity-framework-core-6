﻿using AutoMapper;
using InventoryModels;
using InventoryModels.DTOs;

namespace EFCore5_Activity0903
{
    public class InventoryMapper :  Profile
    {
        public InventoryMapper()
        {
            CreateMaps();
        }

        private void CreateMaps()
        {
            CreateMap<Item, ItemDto>();
            CreateMap<Category, CategoryDto>();
        }
    }
}
